import { Pool } from 'pg'
import { config } from 'dotenv'
config({ path: new URL('../.env', import.meta.url).pathname, quiet: true })
const url = process.env.DATABASE_URL
const allowedDatabases=process.env.NODE_ENV==='production'?['/tochka_gis_prod']:['/tochka_gis_local','/tochka_gis_test'];
if(!url || !allowedDatabases.includes(new URL(url).pathname)) throw Error('Нужна отдельная GIS-база для выбранного окружения')
export const pool = new Pool({ connectionString:url, max:5 })
export const dataDir = new URL('../.data/', import.meta.url).pathname
