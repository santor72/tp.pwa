import { Pool } from 'pg'
import { config } from 'dotenv'
import { fileURLToPath } from 'node:url'

config({ path: fileURLToPath(new URL('../.env', import.meta.url)), quiet: true })
const url = process.env.DATABASE_URL
const allowedDatabases=process.env.NODE_ENV==='production'?['/tochka_gis_prod']:['/tochka_gis_local','/tochka_gis_test'];
if(!url || !allowedDatabases.includes(new URL(url).pathname)) throw Error('Нужна отдельная GIS-база для выбранного окружения')
export const pool = new Pool({ connectionString:url, max:5 })
// URL.pathname leaves non-ASCII filesystem paths percent-encoded. Bun.file()
// needs a native decoded path, including when the repository is under "Документы".
export const dataDir = fileURLToPath(new URL('../.data/', import.meta.url))
