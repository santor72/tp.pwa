import { Hono, type Context } from "hono";
import { PublicError } from "./lib/public-error";
import { recolorIconPng, originalIconColor, DEFAULT_POINT_COLOR } from "./lib/icon-color";
import { assetShapeIndex } from "./lib/icon-catalog-source";
import { errorDiagnostic } from "./lib/error-diagnostic";
import { NETWORK_DETAIL_ZOOM } from "./lib/map-detail";
import { renderGeometry } from './lib/render-geometry';
import { installAccess } from "./auth-routes";
import { requestActor, audit, revisionIdentity } from "./lib/auth";
import {canEditMap} from './lib/access';
import {scopeAccount,layerScope,assetScope} from "./lib/layer-access";
import {installAccessGroups} from "./access-group-routes";
import {installReportRouting} from './report-routing-routes';
import {installStaff} from './staff-routes';
import {featureActivity} from './lib/staff-activity';
import { isDeepStrictEqual, promisify } from "node:util";
import { gzip } from 'node:zlib';
import { z } from "zod";
import { randomUUID } from "node:crypto";
import { readFileSync } from "node:fs";
import { parse as parseEnv } from "dotenv";
import { yandexCsp, yandexScriptUrl } from "./lib/yandex-config";
import { pool, dataDir } from "./lib/db";
import { runtimeConfig, requestAllowed } from "./lib/runtime-config";
import { installReports } from './report-routes';
import { installIntegration } from './integration-routes';
import { installFeedback } from './feedback-routes';
import { installLayerTrash } from './layer-routes';
import { lockActiveFeature } from './lib/layer-state';
import {loadTelegramConfig,startReportDelivery} from './lib/telegram-reports';
import { importMap } from "./lib/import-service";
import { appendImport } from './lib/append-import';
import { normalizedTitle } from './lib/normalize-titles';
import { parseCoordinatesInput, parseArchive } from "./lib/importer";
import { buildArchive } from "./lib/exporter";
import { nearbyBounds } from "./lib/nearby-bounds";
import {
  previewLayerImport,
  applyLayerImport,
} from "./lib/layer-import";

const runtime = runtimeConfig();
// A production-only private runtime file; never copied into the image or browser.
const telegramConfig=runtime.production?await loadTelegramConfig(dataDir+'access/report-bot.json'):null;
const gzipAsync = promisify(gzip);
const app = new Hono(), port = runtime.port;
const cookieName = "gis-local-" + port;
const origin = runtime.origin;
let basemapScript: string | null = null;
try {
  const settings = parseEnv(
    readFileSync(new URL(".data/yandex.env", import.meta.url)),
  );
  basemapScript = yandexScriptUrl(settings.YANDEX_MAPS_API_KEY ?? "");
} catch {
  // An optional/missing key must not prevent opening the local network map.
}
const idSchema = z.string().uuid();
const point = z
  .array(z.number().finite())
  .min(2)
  .max(3)
  .refine((p) => Math.abs(p[0]) <= 180 && Math.abs(p[1]) <= 90);
const geometry = z.discriminatedUnion("type", [
  z.object({ type: z.literal("Point"), coordinates: point }),
  z.object({
    type: z.literal("LineString"),
    coordinates: z.array(point).min(2),
  }),
  z.object({
    type: z.literal("Polygon"),
    coordinates: z
      .array(z.array(point).min(4))
      .min(1)
      .refine((r) =>
        r.every((p) => p[0][0] === p.at(-1)![0] && p[0][1] === p.at(-1)![1]),
      ),
  }),
]);
const hex = z.string().regex(/^#[a-f\d]{6}$/i);
const styleChange = z
  .object({
    lineColor: hex.optional(),
    lineWidth: z.number().finite().min(1).max(20).optional(),
    lineOpacity: z.number().min(0).max(1).optional(),
    fillColor: hex.optional(),
    fillOpacity: z.number().min(0).max(1).optional(),
    iconColor: hex.optional(),
    recolorIcon: z.boolean().optional(),
    markerShape: z.enum(["pin", "circle"]).optional(),
    iconScale: z.number().min(0.3).max(3).optional(),
    iconId: z.string().uuid().nullable().optional(),
  })
  .strict();
const change = z.object({
  version: z.number().int().positive(),
  title: z.string().max(10000),
  description: z.string().max(500000),
  geometry: geometry.optional(),
  style: styleChange.optional(),
});
app.use("*", async (c, next) => {
  c.header("X-Content-Type-Options", "nosniff");
  c.header("Referrer-Policy", "no-referrer");
  c.header("Cache-Control", "no-store");
  const integrationRequest = c.req.path.startsWith('/integration/v1/') && !!c.req.header('authorization');
  if ((!requestAllowed(c.req.header("host"), c.req.method, c.req.header("origin"), c.req.header("sec-fetch-site"), runtime,
    {path:c.req.path,mode:c.req.header('sec-fetch-mode'),dest:c.req.header('sec-fetch-dest')}) &&
    !(integrationRequest && c.req.header('host') === runtime.host)))
    return c.json({ error: "Недопустимый источник запроса" }, 403, {'Content-Type':'application/json; charset=UTF-8'});
  await next();
  if(c.res.headers.get('Content-Type')==='application/json')c.header('Content-Type','application/json; charset=UTF-8');
});
// Explicit launch-only opt-in; ordinary starts remain password-protected.
installAccess(app, cookieName, process.env.GIS_LOCAL_OPEN === "1");
// Compress only the large, authenticated viewport payload; never cache map data.
app.use('/api/geo',async(c,next)=>{
  c.header('Vary','Accept-Encoding');
  const acceptsGzip=(c.req.header('Accept-Encoding')??'').split(',').some(part=>{
    const [name,...params]=part.trim().toLowerCase().split(';');
    const q=params.find(p=>p.trim().startsWith('q='));
    return name==='gzip'&&(!q||Number(q.trim().slice(2))>0);
  });
  await next();
  if(acceptsGzip && c.req.method !== 'HEAD' && c.res.ok &&
    c.res.headers.get('Content-Type')?.includes('application/json') &&
    !c.res.headers.has('Content-Encoding')) {
    // Finish compression before sending: the HTTPS proxy must receive a complete
    // gzip member with a known length, not an open-ended compression stream.
    const body = await gzipAsync(new Uint8Array(await c.res.arrayBuffer()));
    const headers = new Headers(c.res.headers);
    headers.set('Content-Encoding', 'gzip');
    headers.set('Content-Length', String(body.byteLength));
    headers.delete('Transfer-Encoding');
    c.res = new Response(new Uint8Array(body), { status: c.res.status, headers });
  }
});
installReports(app,telegramConfig);
installIntegration(app,telegramConfig);
installAccessGroups(app,readJson);
installReportRouting(app,readJson,telegramConfig);
installStaff(app,readJson);
installFeedback(app);
installLayerTrash(app,readJson);
app.onError((e, c) => {
  if (e instanceof z.ZodError)
    return c.json({ error: "Проверьте введённые данные" }, 400);
  if (e instanceof PublicError)
    return c.json({ error: e.message }, e.status);
  const requestId = randomUUID();
  console.error(JSON.stringify(errorDiagnostic(e, requestId)));
  return c.json({ error: "Внутренняя ошибка сервиса. Повторите запрос позже.", requestId }, 500);
});
async function readJson(c: Context) {
  try { return await c.req.json(); }
  catch { throw new PublicError("Некорректный JSON запроса"); }
}
async function readForm(c: Context) {
  try { return await c.req.formData(); }
  catch { throw new PublicError("Некорректная форма загрузки файла"); }
}
app.get("/health", (c) => c.json({ ok: true, mode: runtime.production ? "server" : "local-only" }));
app.get("/", (c) => {
  c.header("Content-Security-Policy", yandexCsp + "; worker-src blob:");
  return c.html(
    '<!doctype html><html lang="ru"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Точка GIS — карта сети</title><link rel="stylesheet" href="/app.css"></head><body><div id="root"></div><script type="module" src="/app.js"></script></body></html>',
  );
});
// Browser API key: only the local authenticated page receives the SDK URL.
// It is not a server secret; domain restrictions must be configured at Yandex.
app.get("/api/basemap", (c) => c.json({ scriptUrl: basemapScript }));
app.get(
  "/app.js",
  (c) =>
    new Response(Bun.file(`${dataDir}public/app.js`), {
      headers: { "Content-Type": "application/javascript" },
    }),
);
app.get(
  "/app.css",
  (c) =>
    new Response(Bun.file(`${dataDir}public/app.css`), {
      headers: { "Content-Type": "text/css" },
    }),
);
app.post("/api/activity", async c => {
  const input = z.object({ action: z.enum(["map_viewed", "feature_viewed"]), target: z.string().uuid() }).strict().parse(await readJson(c));
  const exists = input.action === "map_viewed"
    ? await pool.query(`SELECT id FROM imports WHERE id=$1 AND ($2::uuid IS NULL OR EXISTS(SELECT 1 FROM layers l WHERE l.import_id=imports.id AND NOT l.deleted AND ${layerScope('l.id','$2')}))`, [input.target,scopeAccount()])
    : await pool.query(`SELECT id FROM features WHERE id=$1 AND NOT deleted AND layer_id IN (SELECT id FROM layers WHERE NOT deleted) AND ${layerScope('layer_id','$2')}`, [input.target,scopeAccount()]);
  if (!exists.rows.length) return c.json({ error: "Объект не найден" }, 404);
  if(input.action==='feature_viewed')await featureActivity(input.action,input.target);
  else await audit(requestActor.getStore()!.id,input.action,input.target,{source:'browser'});
  return c.json({ ok: true });
});
app.get("/api/activity", async c => {
  const cursor = c.req.query("before");
  if (cursor) idSchema.parse(cursor);
  const rows = (await pool.query(`SELECT e.id,e.action,e.target_id,e.detail,
    e.created_at AT TIME ZONE 'UTC' AS created_at,
    CASE WHEN e.detail->>'execution'='local-open' THEN 'Локальный пользователь' ELSE a.name END AS actor_name,
    COALESCE(f.title,l.name,i.name,t.name) AS target_name
    FROM access_audit e LEFT JOIN accounts a ON a.id=e.actor_id
    LEFT JOIN features f ON f.id::text=e.target_id LEFT JOIN layers l ON l.id::text=e.target_id
    LEFT JOIN imports i ON i.id::text=e.target_id LEFT JOIN accounts t ON t.id::text=e.target_id
    WHERE ($1::uuid IS NULL OR (e.created_at,e.id)<(SELECT created_at,id FROM access_audit WHERE id=$1))
    ORDER BY e.created_at DESC,e.id DESC LIMIT 101`, [cursor ?? null])).rows;
  return c.json({ rows: rows.slice(0,100), next: rows.length > 100 ? rows[99].id : null });
});
app.get('/api/maps',async c=>{
  const account=scopeAccount();
  if(account===null)return c.json((await pool.query('SELECT id,name,report,created_at FROM imports ORDER BY created_at DESC')).rows);
  // Resolve allowed layers once. Rechecking grants in a correlated count for every
  // import caused expensive PostgreSQL JIT compilation on larger catalogues.
  return c.json((await pool.query(`WITH allowed_layers AS MATERIALIZED (
    SELECT l.id,l.import_id FROM layers l WHERE NOT l.deleted AND ${layerScope('l.id','$1')}
  ) SELECT i.id,i.name,jsonb_build_object('total',count(f.id)) report,i.created_at
    FROM allowed_layers l JOIN imports i ON i.id=l.import_id
    LEFT JOIN features f ON f.layer_id=l.id AND NOT f.deleted
    GROUP BY i.id,i.name,i.created_at ORDER BY i.created_at DESC`,[account])).rows);
});
app.get("/api/layers", async (c) => {
  const id = idSchema.parse(c.req.query("map"));
  return c.json(
    (
      await pool.query(
        `SELECT id,name,position,count,next_number,version FROM layers WHERE import_id=$1 AND NOT deleted AND ${layerScope('id','$2')} ORDER BY position,id`,
        [id,scopeAccount()],
      )
    ).rows,
  );
});
app.get("/api/map-health", async (c) => {
  const id = idSchema.parse(c.req.query("map"));
  const r = await pool.query(
    `SELECT count(*)::int total,count(*) FILTER (WHERE f.geom IS NULL)::int "invalidGeometry",
    count(*) FILTER (WHERE ST_YMax(Box3D(f.geom))>85.05112878 OR ST_YMin(Box3D(f.geom))< -85.05112878)::int "outsideProjection"
    FROM features f JOIN layers l ON l.id=f.layer_id WHERE l.import_id=$1 AND NOT l.deleted AND NOT f.deleted AND ${layerScope('l.id','$2')}`,
    [id,scopeAccount()],
  );
  return c.json(r.rows[0]);
});
app.get("/api/source-issues", async (c) => {
  const id = idSchema.parse(c.req.query("map"));
  return c.json({
    title: "Особенности координат исходника",
    results: (
      await pool.query(
        `SELECT f.id,f.title,f.kind,f.number,f.style,l.name layer_name,l.id layer_id FROM features f JOIN layers l ON l.id=f.layer_id
    WHERE l.import_id=$1 AND NOT l.deleted AND NOT f.deleted AND ${layerScope('l.id','$2')} AND (f.geom IS NULL OR ST_YMax(Box3D(f.geom))>85.05112878 OR ST_YMin(Box3D(f.geom))< -85.05112878) ORDER BY l.position,f.number LIMIT 100`,
        [id,scopeAccount()],
      )
    ).rows,
  });
});
app.post("/api/layers", async (c) => {
  const body = z
      .object({ map_id: idSchema, name: z.string().trim().min(1).max(200) })
      .parse(await readJson(c)),
    db = await pool.connect();
  try {
    await db.query("BEGIN");
    if (
      !(
        await db.query("SELECT id FROM imports WHERE id=$1 FOR UPDATE", [
          body.map_id,
        ])
      ).rows.length
    ) {
      await db.query("ROLLBACK");
      return c.json({ error: "Карта не найдена" }, 404);
    }
    const r = await db.query(
      "INSERT INTO layers (id,import_id,name,position,count,next_number) SELECT $1,$2,$3,COALESCE(MAX(position),-1)+1,0,1 FROM layers WHERE import_id=$2 RETURNING *",
      [randomUUID(), body.map_id, body.name],
    );
    await audit(requestActor.getStore()!.id, "layer_created", r.rows[0].id, { map_id: body.map_id, name: body.name }, db);
    await db.query("COMMIT");
    return c.json(r.rows[0], 201);
  } catch (e) {
    await db.query("ROLLBACK");
    throw e;
  } finally {
    db.release();
  }
});
app.patch("/api/layers/:id", async (c) => {
  const id = idSchema.parse(c.req.param("id")),
    body = z
      .object({ name: z.string().trim().min(1).max(200) })
      .parse(await readJson(c));
  const db = await pool.connect();
  try {
    await db.query("BEGIN");
    const old = (await db.query("SELECT name,import_id FROM layers WHERE id=$1 AND NOT deleted FOR UPDATE", [id])).rows[0];
    if (!old) { await db.query("ROLLBACK"); return c.json({ error: "Слой не найден" }, 404); }
    if (old.name !== body.name) {
      await db.query("UPDATE layers SET name=$2,version=version+1 WHERE id=$1", [id, body.name]);
      await audit(requestActor.getStore()!.id, "layer_renamed", id, { map_id: old.import_id, before: old.name, after: body.name }, db);
    }
    await db.query("COMMIT");
    return c.json({ id, name: body.name });
  } catch (error) { await db.query("ROLLBACK"); throw error; }
  finally { db.release(); }
});
app.post("/api/layers/order", async (c) => {
  const body = z
    .object({
      map_id: idSchema,
      before: z.array(idSchema),
      order: z.array(idSchema),
    })
    .parse(await readJson(c));
  const db = await pool.connect();
  try {
    await db.query("BEGIN");
    await db.query("SELECT id FROM imports WHERE id=$1 FOR UPDATE", [
      body.map_id,
    ]);
    const ids = (
      await db.query(
        "SELECT id FROM layers WHERE import_id=$1 AND NOT deleted ORDER BY position,id",
        [body.map_id],
      )
    ).rows.map((l) => l.id);
    if (JSON.stringify(ids) !== JSON.stringify(body.before)) {
      await db.query("ROLLBACK");
      return c.json(
        {
          error: "Список слоёв изменился. Обновите карту перед перестановкой.",
        },
        409,
      );
    }
    if (
      !ids.length ||
      body.order.length !== ids.length ||
      new Set(body.order).size !== ids.length ||
      body.order.some((id) => !ids.includes(id))
    ) {
      await db.query("ROLLBACK");
      return c.json(
        { error: "В новом порядке должны остаться все слои этой карты" },
        400,
      );
    }
    await db.query(
      "UPDATE layers SET position=u.position-1 FROM unnest($1::uuid[]) WITH ORDINALITY AS u(id,position) WHERE layers.id=u.id",
      [body.order],
    );
    if (JSON.stringify(ids) !== JSON.stringify(body.order))
      await audit(requestActor.getStore()!.id, "layers_reordered", body.map_id, { before: ids, after: body.order }, db);
    await db.query("COMMIT");
    return c.json({ ok: true });
  } catch (e) {
    await db.query("ROLLBACK");
    throw e;
  } finally {
    db.release();
  }
});
app.get('/api/trash', async(c)=>{
  const mapId=idSchema.parse(c.req.query('map'));
  const after=c.req.query('after') ? idSchema.parse(c.req.query('after')) : null;
  const rows=(await pool.query(`SELECT f.id,f.title,f.kind,f.version,l.name layer_name FROM features f JOIN layers l ON l.id=f.layer_id
    WHERE l.import_id=$1 AND NOT l.deleted AND f.deleted AND ($2::uuid IS NULL OR f.id>$2) ORDER BY f.id LIMIT 101`,[mapId,after])).rows;
  return c.json({rows:rows.slice(0,100),next:rows.length>100?rows[99].id:null});
});
for(const operation of ['trash','restore'] as const) app.post('/api/features/:id/'+operation,async(c)=>{
  const id=idSchema.parse(c.req.param('id'));
  const {version}=z.object({version:z.number().int().positive()}).strict().parse(await readJson(c));
  const deleted=operation==='trash',db=await pool.connect();
  try{
    await db.query('BEGIN');
    const old=await lockActiveFeature(db,id,{includeDeleted:true,layerWrite:true});
    if(old.version!==version)throw new PublicError('Объект уже изменён. Обновите карточку или корзину.',409);
    if(old.deleted===deleted){await db.query('COMMIT');return c.json({ok:true,version,unchanged:true});}
    await db.query('UPDATE layers SET count=count+$2 WHERE id=$1',[old.layer_id,deleted?-1:1]);
    await db.query('UPDATE features SET deleted=$2,version=version+1 WHERE id=$1',[id,deleted]);
    const identity=revisionIdentity();
    await db.query('INSERT INTO revisions(id,feature_id,before,after,actor_id) VALUES($1,$2,$3,$4,$5)',[
      randomUUID(),id,{deleted:old.deleted,version},{deleted,version:version+1,execution:identity.execution},identity.actorId]);
    await audit(requestActor.getStore()!.id,deleted?'feature_trashed':'feature_restored',id,{version:version+1},db);
    await db.query('COMMIT');return c.json({ok:true,version:version+1});
  }catch(e){await db.query('ROLLBACK');throw e;}finally{db.release();}
});
app.get("/api/features/:id/revisions", async (c) => {
  const id = idSchema.parse(c.req.param("id"));
  if(!(await pool.query(`SELECT f.id FROM features f JOIN layers l ON l.id=f.layer_id WHERE f.id=$1 AND NOT l.deleted AND ${layerScope('f.layer_id','$2')}`,[id,scopeAccount()])).rowCount)throw new PublicError('Объект не найден',404);
  return c.json(
    (
      await pool.query(
        // Prisma DateTime is timestamp without timezone; this DB writes UTC.
        // Make the instant explicit before pg serializes it in the host timezone.
        "SELECT r.id,r.before,r.after,r.actor_id,a.name AS actor_name,r.created_at AT TIME ZONE 'UTC' AS created_at FROM revisions r LEFT JOIN accounts a ON a.id=r.actor_id WHERE r.feature_id=$1 ORDER BY r.created_at DESC,r.id DESC LIMIT 100",
        [id],
      )
    ).rows,
  );
});
app.post("/api/features/:id/move", async (c) => {
  const id = idSchema.parse(c.req.param("id"));
  const body = z
    .object({ version: z.number().int().positive(), layer_id: idSchema, numbering:z.enum(['preserve','next']).default('next') }).strict()
    .parse(await readJson(c));
  const db = await pool.connect();
  try {
    await db.query("BEGIN");
    const old = (
      await db.query(
        "SELECT * FROM features WHERE id=$1 AND NOT deleted",
        [id],
      )
    ).rows[0];
    if (!old) {
      await db.query("ROLLBACK");
      return c.json({ error: "Объект не найден" }, 404);
    }
    if (old.version !== body.version) {
      await db.query("ROLLBACK");
      return c.json({ error: "Объект уже изменён. Откройте его заново." }, 409);
    }
    // A consistent lock order also protects simultaneous moves in opposite directions.
    const layers = (
      await db.query(
        "SELECT * FROM layers WHERE id=ANY($1::uuid[]) ORDER BY id FOR UPDATE",
        [[old.layer_id, body.layer_id]],
      )
    ).rows;
    const source = layers.find((l) => l.id === old.layer_id),
      target = layers.find((l) => l.id === body.layer_id);
    if (!source || source.deleted || !target || target.deleted || source.import_id !== target.import_id) {
      await db.query("ROLLBACK");
      return c.json({ error: "Выберите слой этой же карты" }, 400);
    }
    const locked=(await db.query('SELECT version,layer_id,deleted FROM features WHERE id=$1 FOR UPDATE',[id])).rows[0];
    if(!locked||locked.deleted||locked.version!==old.version||locked.layer_id!==old.layer_id)throw new PublicError('Объект изменился. Откройте карточку заново.',409);
    if (old.layer_id === target.id) {
      await db.query("COMMIT");
      return c.json({ ok: true, version: old.version });
    }
    const number = body.numbering==='preserve'?old.number:target.next_number;
    if(body.numbering==='preserve'&&(await db.query('SELECT id FROM features WHERE layer_id=$1 AND number=$2',[target.id,number])).rowCount)
      throw new PublicError('Номер '+number+' уже занят в выбранном слое (в том числе в корзине). Выберите следующий порядковый номер.',409);
    const title=body.numbering==='preserve'?old.title:normalizedTitle(old.title,old.kind,number);
    await db.query(
      "UPDATE layers SET next_number=GREATEST(next_number,$2+1),count=count+1 WHERE id=$1",
      [target.id,number],
    );
    await db.query("UPDATE layers SET count=count-1 WHERE id=$1", [source.id]);
    await db.query(
      "UPDATE features SET layer_id=$2,number=$3,title=$4,version=version+1 WHERE id=$1",
      [id, target.id, number,title],
    );
    await db.query(
      "INSERT INTO revisions (id,feature_id,before,after,actor_id) VALUES ($1,$2,$3,$4,$5)",
      [
        randomUUID(),
        id,
        {
          layer_id: source.id,
          layer_name: source.name,
          number: old.number,
          title: old.title,
          version: old.version,
        },
        {
          layer_id: target.id,
          layer_name: target.name,
          number,
          title,
          version: old.version + 1,
          execution: revisionIdentity().execution,
        },
        revisionIdentity().actorId,
      ],
    );
    await audit(requestActor.getStore()!.id, "feature_moved_layer", id, { from: source.id, to: target.id, numbering:body.numbering,number,title }, db);
    await db.query("COMMIT");
    return c.json({ ok: true, version: old.version + 1 });
  } catch (e) {
    await db.query("ROLLBACK");
    throw e;
  } finally {
    db.release();
  }
});
app.get("/api/icons", async (c) => {
  const id = idSchema.parse(c.req.query("map"));
  const assets = (await pool.query(`SELECT a.id,a.source_path,a.disk_name FROM assets a WHERE a.import_id=$1 AND ${assetScope('a.id','$2')} ORDER BY a.source_path`, [id,scopeAccount()])).rows;
  const shapes = await assetShapeIndex(dataDir, assets);
  return c.json(await Promise.all(assets.map(async ({disk_name,...asset}) => {
    const shape = shapes.get(asset.id) ?? null;
    try { return {...asset, shape, color:originalIconColor(new Uint8Array(await Bun.file(dataDir+disk_name).arrayBuffer()))}; }
    catch { return {...asset, shape, color:null}; }
  })));
});
app.get("/api/bounds", async (c) => {
  const ids = (c.req.query("layers") ?? "")
    .split(",")
    .filter(Boolean)
    .map((i) => idSchema.parse(i));
  const r = await pool.query(
    `SELECT ST_XMin(e) xmin,ST_YMin(e) ymin,ST_XMax(e) xmax,ST_YMax(e) ymax FROM (SELECT ST_Extent(geom) e FROM features WHERE layer_id=ANY($1::uuid[]) AND layer_id IN (SELECT id FROM layers WHERE NOT deleted) AND NOT deleted AND ${layerScope('layer_id','$2')} AND ST_YMax(Box3D(geom))<=85.05112878 AND ST_YMin(Box3D(geom))>= -85.05112878)t`,
    [ids,scopeAccount()],
  );
  return c.json(r.rows[0]);
});
app.get("/api/geo", async (c) => {
  const ids = (c.req.query("layers") ?? "")
    .split(",")
    .filter(Boolean)
    .map((i) => idSchema.parse(i));
  const bounds = z
    .array(z.number().finite())
    .length(4)
    .parse((c.req.query("bbox") ?? "-180,-85,180,85").split(",").map(Number));
  // Omitted zoom keeps compatibility with existing verification tools.
  const zoom = z.coerce.number().finite().min(0).max(24).parse(c.req.query("zoom") ?? NETWORK_DETAIL_ZOOM);
  const overview = zoom < NETWORK_DETAIL_ZOOM;
  const render = z.enum(['0', '1']).optional().parse(c.req.query('render')) === '1';
  const r = await pool.query(
    `SELECT id,layer_id,number,kind,title,geometry,style,geom IS NULL AS issue FROM features
    WHERE layer_id=ANY($1::uuid[]) AND layer_id IN (SELECT id FROM layers WHERE NOT deleted) AND NOT deleted AND ${layerScope('layer_id','$6')} AND (geom && ST_MakeEnvelope($2,$3,$4,$5,4326) OR geom IS NULL) ORDER BY number,id LIMIT 40001`,
    [ids, ...bounds,scopeAccount()],
  );
  // One compact batch event, not thousands of invented card views. These are
  // viewport coordinates, never device GPS; no descriptions or payload copy.
  await audit(requestActor.getStore()!.id,'geo_data_served',null,{source:'server',
    layer_ids:[...new Set(r.rows.map(f=>f.layer_id))],bbox:bounds.map(v=>Number(v.toFixed(4))),
    zoom:Number(zoom.toFixed(2)),count:Math.min(r.rows.length,40000),truncated:r.rows.length>40000});
  return c.json({
    type: "FeatureCollection",
    overview,
    minDetailZoom: NETWORK_DETAIL_ZOOM,
    truncated: r.rows.length > 40000,
    limit: 40000,
    features: r.rows.slice(0, 40000).map((f) => ({
      type: "Feature",
      id: f.id,
      geometry:
        f.issue && f.kind === "LineString"
          ? { type: "Point", coordinates: f.geometry.coordinates[0] }
          : render ? renderGeometry(f.geometry, zoom) : f.geometry,
      properties: {
        id: f.id,
        layer_id: f.layer_id,
        // Cards/search/edit/export use the full stored geometry, never this
        // optional display-only simplification. Points and styles are unchanged.
        ...(!overview ? { number: f.number, title: f.title } : {}),
        kind: f.kind,
        issue: f.issue,
        ...f.style,
      },
    })),
  });
});
app.get("/api/features/:id", async (c) => {
  const id = idSchema.parse(c.req.param("id"));
  const r = await pool.query(
    `SELECT f.id,f.layer_id,f.number,f.kind,f.title,f.source_name,f.description,f.geometry,f.style,f.version,f.closure_full,f.geom IS NULL issue,(ST_YMax(Box3D(f.geom))>85.05112878 OR ST_YMin(Box3D(f.geom))< -85.05112878) outside_projection,l.name layer_name FROM features f JOIN layers l ON l.id=f.layer_id WHERE f.id=$1 AND NOT f.deleted AND NOT l.deleted AND ${layerScope('f.layer_id','$2')}`,
    [id,scopeAccount()],
  );
  const feature=r.rows[0];
  if(!feature)return c.json({error:'Объект не найден'},404);
  // Never expose UserSide identity through broadly readable geometry/history payloads.
  // Navigation still requires the user's independent UserSide session.
  if(feature.kind==='Point'&&canEditMap(requestActor.getStore()!.role)){
    const link=(await pool.query('SELECT node_id FROM feature_userside_links WHERE feature_id=$1',[id])).rows[0];
    if(link&&Number.isInteger(link.node_id)&&link.node_id>0){
      feature.userside_scheme='https://point-us.dm.point.online/oper/?core_section=commutation_scheme&action=show&id='+link.node_id;
    }
  }
  await featureActivity('feature_data_served',id);
  return c.json(feature);
});
app.get("/api/list", async (c) => {
  const layer = idSchema.parse(c.req.query("layer")),
    all =
      z.enum(["true", "false"]).parse(c.req.query("all") ?? "false") === "true",
    offset = z.coerce
      .number()
      .int()
      .min(0)
      .parse(c.req.query("offset") ?? 0);
  return c.json(
    (
      await pool.query(
        `SELECT id,number,title,kind,style FROM features WHERE layer_id=$1 AND layer_id IN (SELECT id FROM layers WHERE NOT deleted) AND NOT deleted AND ${layerScope('layer_id','$4')} ORDER BY number LIMIT $3 OFFSET $2`,
        [layer, all ? 0 : offset, all ? null : 100,scopeAccount()],
      )
    ).rows,
  );
});
app.get("/api/search", async (c) => {
  const map = idSchema.parse(c.req.query("map")),
    q = (c.req.query("q") ?? "").trim().slice(0, 1000);
  const coord = parseCoordinatesInput(q),
    radius = z.coerce
      .number()
      .min(1)
      .max(100000)
      .parse(c.req.query("radius") ?? 500);
  if (coord) {
    const bbox = nearbyBounds(coord, radius);
    const r = await pool.query(
      `SELECT f.id,f.number,f.title,f.kind,f.style,l.name layer_name,l.id layer_id,
      ST_Distance(f.geom::geography,ST_SetSRID(ST_Point($2,$3),4326)::geography) distance
      FROM features f JOIN layers l ON f.layer_id=l.id WHERE l.import_id=$1 AND NOT l.deleted AND NOT f.deleted AND ${layerScope('l.id','$10')} AND f.geom IS NOT NULL
      AND ($5::boolean OR f.geom && ST_MakeEnvelope($6,$7,$8,$9,4326))
      AND ST_DWithin(f.geom::geography,ST_SetSRID(ST_Point($2,$3),4326)::geography,$4) ORDER BY distance,f.id LIMIT 100`,
      [map, ...coord, radius, !bbox, ...(bbox ?? [-180, -90, 180, 90]),scopeAccount()],
    );
    return c.json({ coordinates: coord, results: r.rows });
  }
  if (!q) return c.json({ results: [] });
  const r = await pool.query(
    `SELECT f.id,f.number,f.title,f.kind,f.style,l.name layer_name,l.id layer_id FROM features f JOIN layers l ON f.layer_id=l.id WHERE l.import_id=$1 AND NOT l.deleted AND NOT f.deleted AND ${layerScope('l.id','$4')}
    AND (f.title ILIKE $2 OR f.source_name ILIKE $2 OR f.description ILIKE $2 OR f.number::text=$3) ORDER BY l.position,f.number LIMIT 100`,
    [map, "%" + q.replace(/[\\%_]/g, "\\$&") + "%", q,scopeAccount()],
  );
  return c.json({ results: r.rows });
});
app.patch("/api/features/:id", async (c) => {
  const id = idSchema.parse(c.req.param("id")),
    body = change.parse(await readJson(c)),
    db = await pool.connect();
  try {
    await db.query("BEGIN");
    const old = await lockActiveFeature(db,id);
    if (!old) {
      await db.query("ROLLBACK");
      return c.json({ error: "Объект не найден" }, 404);
    }
    if (old.version !== body.version) {
      await db.query("ROLLBACK");
      return c.json(
        { error: "Объект изменился в другой вкладке. Откройте его заново." },
        409,
      );
    }
    if (body.geometry && body.geometry.type !== old.kind) {
      await db.query("ROLLBACK");
      return c.json({ error: "Нельзя менять тип существующего объекта" }, 400);
    }
    if (body.style?.iconId) {
      const asset = await db.query(
        "SELECT a.id FROM assets a JOIN layers l ON l.import_id=a.import_id WHERE l.id=$1 AND a.id=$2",
        [old.layer_id, body.style.iconId],
      );
      if (!asset.rows.length) {
        await db.query("ROLLBACK");
        return c.json({ error: "Значок не принадлежит этой карте" }, 400);
      }
    }
    const geo = body.geometry ?? old.geometry,
      style = { ...old.style, ...body.style };
    // Imported null iconId means an external URL; an explicit editor reset means no image.
    if (body.style && Object.hasOwn(body.style, "iconId") && body.style.iconId === null)
      style.icon = "";
    if (body.style && style.iconId && style.recolorIcon) {
      const asset = (await db.query("SELECT disk_name FROM assets WHERE id=$1", [style.iconId])).rows[0];
      recolorIconPng(new Uint8Array(await Bun.file(dataDir + asset.disk_name).arrayBuffer()), style.iconColor ?? DEFAULT_POINT_COLOR);
    }
    if (body.title === old.title && body.description === old.description &&
        isDeepStrictEqual(geo, old.geometry) && isDeepStrictEqual(style, old.style)) {
      await db.query("COMMIT");
      return c.json({ ok: true, version: old.version, unchanged: true });
    }
    await db.query(
      `UPDATE features SET title=$2,description=$3,geometry=$4,style=$5,version=version+1,
      geom=CASE WHEN $6 THEN ST_Force2D(ST_SetSRID(ST_GeomFromGeoJSON($4::jsonb),4326)) ELSE geom END WHERE id=$1`,
      [
        id,
        body.title,
        body.description,
        JSON.stringify(geo),
        style,
        !!body.geometry,
      ],
    );
    await db.query(
      "INSERT INTO revisions (id,feature_id,before,after,actor_id) VALUES ($1,$2,$3,$4,$5)",
      [
        randomUUID(),
        id,
        {
          title: old.title,
          description: old.description,
          geometry: old.geometry,
          style: old.style,
          version: old.version,
        },
        { ...body, geometry: geo, style, version: old.version + 1, execution: revisionIdentity().execution },
        revisionIdentity().actorId,
      ],
    );
    await audit(requestActor.getStore()!.id, "feature_changed", id, { version: old.version + 1 }, db);
    await db.query("COMMIT");
    return c.json({ ok: true, version: old.version + 1 });
  } catch (e) {
    await db.query("ROLLBACK");
    throw e;
  } finally {
    db.release();
  }
});
app.post("/api/features", async (c) => {
  const body = z
    .object({
      layer_id: z.string().uuid(),
      geometry,
      title: z.string().max(10000).default(""),
      description: z.string().max(500000).default(""),
    })
    .parse(await readJson(c));
  const db = await pool.connect();
  try {
    await db.query("BEGIN");
    const layer = (
      await db.query(
        "UPDATE layers SET next_number=next_number+1,count=count+1 WHERE id=$1 AND NOT deleted RETURNING next_number-1 number",
        [body.layer_id],
      )
    ).rows[0];
    if (!layer) throw new PublicError("Выберите слой", 404);
    const id = randomUUID(),
      style = {
        lineColor: "#000000",
        lineWidth: 3,
        lineOpacity: 1,
        fillColor: "#ab47bc",
        fillOpacity: 0.2,
        iconColor: "#0288d1",
        markerShape: "pin",
        iconId: null,
      };
    await db.query(
      `INSERT INTO features (id,layer_id,number,kind,title,source_name,description,source_description,geometry,source_geometry,style,properties,source_raw,geom,version,deleted)
      VALUES ($1,$2,$3,$4,$5,'',$6,'',$7,$7,$8,'{}','{}',ST_Force2D(ST_SetSRID(ST_GeomFromGeoJSON($7::jsonb),4326)),1,false)`,
      [
        id,
        body.layer_id,
        layer.number,
        body.geometry.type,
        body.title ||
          { Point: "Точка", LineString: "Линия", Polygon: "Полигон" }[
            body.geometry.type
          ] +
            " " +
            layer.number,
        body.description,
        JSON.stringify(body.geometry),
        style,
      ],
    );
    await audit(requestActor.getStore()!.id, "feature_created", id, { layer_id: body.layer_id, number: layer.number }, db);
    await db.query("COMMIT");
    return c.json({ id, number: layer.number }, 201);
  } catch (e) {
    await db.query("ROLLBACK");
    throw e;
  } finally {
    db.release();
  }
});
app.get("/api/assets/:id", async (c) => {
  const id = idSchema.parse(c.req.param("id")),
    r = await pool.query(`SELECT a.disk_name FROM assets a WHERE a.id=$1 AND ${assetScope('a.id','$2')}`, [id,scopeAccount()]);
  if (!r.rows[0]) return c.notFound();
  const color = c.req.query("color");
  if (color !== undefined && !/^[a-f\d]{6}$/i.test(color)) throw new PublicError("Некорректный цвет значка");
  const file = Bun.file(dataDir + r.rows[0].disk_name);
  return new Response(color ? recolorIconPng(new Uint8Array(await file.arrayBuffer()), "#" + color) : file, {
    headers: {
      "Content-Type": "image/png",
      "Cache-Control": "no-store",
    },
  });
});
app.post("/api/import", async (c) => {
  const form = await readForm(c),
    file = form.get("file");
  if (!(file instanceof File))
    return c.json({ error: "Выберите KML или KMZ" }, 400);
  return c.json(
    await importMap(new Uint8Array(await file.arrayBuffer()), file.name),
  );
});
app.post("/api/import-preview", async (c) => {
  const form = await readForm(c),
    file = form.get("file");
  if (!(file instanceof File)) return c.json({ error: "Выберите файл" }, 400);
  const p = parseArchive(new Uint8Array(await file.arrayBuffer()));
  return c.json({
    name: p.name,
    layers: p.layers.map((l, index) => ({
      index,
      name: l.name,
      count: l.features.length,
    })),
    total: p.layers.reduce((n, l) => n + l.features.length, 0),
    icons: p.icons.size,
  });
});
app.post('/api/import/append',async(c)=>{
  const form=await readForm(c),file=form.get('file');
  if(!(file instanceof File))throw new PublicError('Выберите KML или KMZ');
  const mode=z.enum(['layer','layers']).parse(form.get('mode'));
  const numbering=z.enum(['new','preserve']).parse(form.get('numbering'));
  const mapId=idSchema.parse(form.get('map_id'));
  const layer=mode==='layer'?idSchema.parse(form.get('layer_id')):null;
  return c.json(await appendImport(new Uint8Array(await file.arrayBuffer()),file.name,mapId,mode,layer,numbering));
});
for (const action of ["preview", "apply"] as const)
  app.post("/api/import-layer/" + action, async (c) => {
    const form = await readForm(c),
      file = form.get("file");
    if (!(file instanceof File))
      return c.json({ error: "Выберите KML или KMZ" }, 400);
    const layer = idSchema.parse(form.get("layer_id"));
    const source = z.coerce
      .number()
      .int()
      .min(0)
      .parse(form.get("source_layer") ?? 0);
    const bytes = new Uint8Array(await file.arrayBuffer());
    if (action === "preview")
      return c.json(await previewLayerImport(bytes, layer, source));
    const token = z
      .string()
      .regex(/^[a-f0-9]{64}$/)
      .parse(form.get("token"));
    let accepted: unknown;
    try { accepted = JSON.parse(String(form.get("accept_changes") ?? "[]")); }
    catch { throw new PublicError("Некорректный JSON подтверждения импорта"); }
    const accept = z
      .array(z.number().int().min(0))
      .parse(accepted);
    return c.json(
      await applyLayerImport(bytes, file.name, layer, source, token, accept),
    );
  });
app.get("/api/export/:id", async (c) => {
  const id = idSchema.parse(c.req.param("id"));
  if (
    !(await pool.query("SELECT id FROM imports WHERE id=$1", [id])).rows.length
  )
    return c.notFound();
  const file = Bun.file(`${dataDir}imports/${id}/original.kmz`);
  const head = new Uint8Array(await file.slice(0, 2).arrayBuffer());
  const zipped = head[0] === 80 && head[1] === 75;
  return new Response(file, {
    headers: {
      "Content-Disposition": `attachment; filename="original.${zipped ? "kmz" : "kml"}"`,
      "Content-Type": zipped
        ? "application/vnd.google-earth.kmz"
        : "application/vnd.google-earth.kml+xml",
    },
  });
});
app.get("/api/export-current/:id", async (c) => {
  const id = idSchema.parse(c.req.param("id")),
    db = await pool.connect();
  try {
    await db.query("BEGIN ISOLATION LEVEL REPEATABLE READ READ ONLY");
    const source = (
      await db.query("SELECT name FROM imports WHERE id=$1", [id])
    ).rows[0];
    if (!source) {
      await db.query("ROLLBACK");
      return c.notFound();
    }
    const layers = (
      await db.query(
        "SELECT id,name FROM layers WHERE import_id=$1 AND NOT deleted ORDER BY position,id",
        [id],
      )
    ).rows;
    const features = (
      await db.query(
        "SELECT f.* FROM features f JOIN layers l ON l.id=f.layer_id WHERE l.import_id=$1 AND NOT l.deleted AND NOT f.deleted ORDER BY l.position,f.number",
        [id],
      )
    ).rows;
    const assets = (
      await db.query("SELECT id,disk_name FROM assets WHERE import_id=$1", [id])
    ).rows;
    await db.query("COMMIT");
    const icons = new Map<string, Uint8Array>();
    for (const a of assets)
      icons.set(
        a.id,
        new Uint8Array(await Bun.file(dataDir + a.disk_name).arrayBuffer()),
      );
    const grouped = new Map<string, any[]>();
    for (const f of features) {
      if (!grouped.has(f.layer_id)) grouped.set(f.layer_id, []);
      grouped.get(f.layer_id)!.push(f);
    }
    const bytes = buildArchive(
      {
        name: source.name,
        layers: layers.map((l) => ({
          ...l,
          features: grouped.get(l.id) ?? [],
        })),
      },
      icons,
    );
    return new Response(new Uint8Array(bytes).buffer, {
      headers: {
        "Content-Disposition": `attachment; filename="tochka-gis-${new Date().toISOString().slice(0, 10)}.kmz"`,
        "Content-Type": "application/vnd.google-earth.kmz",
      },
    });
  } catch (e) {
    await db.query("ROLLBACK");
    throw e;
  } finally {
    db.release();
  }
});
export default {
  port,
  hostname: runtime.hostname,
  fetch: app.fetch,
  maxRequestBodySize: 55 * 1024 * 1024,
  idleTimeout: 120,
};
console.log(`Точка GIS: ${origin} (${runtime.production ? "server" : "только этот компьютер"})`);
if(telegramConfig)startReportDelivery(pool,telegramConfig,dataDir+'photos/');
