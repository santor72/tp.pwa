CREATE TABLE "integration_report_receipts" (
  "client_id" TEXT NOT NULL,
  "external_report_id" UUID NOT NULL,
  "feature_report_id" UUID NOT NULL,
  "fingerprint" TEXT NOT NULL,
  "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "integration_report_receipts_pkey" PRIMARY KEY ("client_id", "external_report_id"),
  CONSTRAINT "integration_report_receipts_feature_report_id_key" UNIQUE ("feature_report_id"),
  CONSTRAINT "integration_report_receipts_feature_report_id_fkey" FOREIGN KEY ("feature_report_id") REFERENCES "feature_history_entries"("id") ON DELETE RESTRICT ON UPDATE CASCADE
);
