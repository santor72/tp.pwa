import { expect, test } from 'bun:test';
import { createHash } from 'node:crypto';
import { integrationAuthorized, integrationConfig, integrationMapAllowed } from '../lib/integration-config';

const token = 'integration-token-with-at-least-thirty-two-characters';
const tokenHash = createHash('sha256').update(token).digest('hex');
const first = '11111111-1111-4111-8111-111111111111';
const second = '22222222-2222-4222-8222-222222222222';

test('integration is disabled until an explicit token is configured', () => {
  expect(integrationConfig({})).toBeNull();
  expect(() => integrationConfig({ GIS_INTEGRATION_TOKEN: 'short' })).toThrow();
});

test('production requires an explicit published-map allowlist', () => {
  expect(() => integrationConfig({ NODE_ENV: 'production', GIS_INTEGRATION_TOKEN: token })).toThrow();
  const config = integrationConfig({ NODE_ENV: 'production', GIS_INTEGRATION_TOKEN_SHA256: tokenHash, GIS_INTEGRATION_CLIENT_ID: 'tp-pwa', GIS_INTEGRATION_MAP_IDS: `${first},${second}` })!;
  expect(integrationMapAllowed(first, config)).toBe(true);
  expect(integrationMapAllowed(crypto.randomUUID(), config)).toBe(false);
  expect(config.reportGeometryTypes).toEqual(['Point', 'LineString']);
  expect(config.photoRetentionDays).toBe(365);
});

test('report types and photo retention are an explicit, bounded contract', () => {
  const config = integrationConfig({ GIS_INTEGRATION_TOKEN: token, GIS_INTEGRATION_REPORT_GEOMETRY_TYPES: 'Point,Polygon', GIS_INTEGRATION_PHOTO_RETENTION_DAYS: '730' })!;
  expect(config.reportGeometryTypes).toEqual(['Point', 'Polygon']);
  expect(config.photoRetentionDays).toBe(730);
  expect(() => integrationConfig({ GIS_INTEGRATION_TOKEN: token, GIS_INTEGRATION_REPORT_GEOMETRY_TYPES: 'Circle' })).toThrow();
  expect(() => integrationConfig({ GIS_INTEGRATION_TOKEN: token, GIS_INTEGRATION_PHOTO_RETENTION_DAYS: '1' })).toThrow();
});

test('bearer comparison accepts only the configured full token', () => {
  const config = integrationConfig({ GIS_INTEGRATION_TOKEN_SHA256: tokenHash })!;
  expect(integrationAuthorized(`Bearer ${token}`, config)).toBe(true);
  expect(integrationAuthorized(`Bearer ${token}x`, config)).toBe(false);
  expect(integrationAuthorized('Basic anything', config)).toBe(false);
  expect(integrationAuthorized(undefined, config)).toBe(false);
});
