import type { IntegrationConfig } from './lib/integration-config';

const uuid = { type: 'string', format: 'uuid' };
const error = { type: 'object', required: ['error'], properties: { code: { type: 'string', description: 'Машинный код, если он определён для ошибки' }, error: { type: 'string' } } };
const response = (schema: object, description = 'OK') => ({ description, content: { 'application/json': { schema } } });
const idParameter = { name: 'id', in: 'path', required: true, schema: uuid };

export function integrationOpenApi(config: IntegrationConfig) {
  const schemas = {
    Error: error,
    Map: { type: 'object', required: ['id', 'name', 'created_at', 'report'], properties: { id: uuid, name: { type: 'string' }, created_at: { type: 'string', format: 'date-time' }, report: { type: 'object', required: ['total'], properties: { total: { type: 'integer', minimum: 0 } } } } },
    Layer: { type: 'object', required: ['id', 'name', 'position', 'count', 'version'], properties: { id: uuid, name: { type: 'string' }, position: { type: 'integer' }, count: { type: 'integer', minimum: 0 }, version: { type: 'integer', minimum: 1 } } },
    Bounds: { type: 'object', required: ['xmin', 'ymin', 'xmax', 'ymax'], properties: { xmin: { type: 'number', minimum: -180, maximum: 180 }, ymin: { type: 'number', minimum: -90, maximum: 90 }, xmax: { type: 'number', minimum: -180, maximum: 180 }, ymax: { type: 'number', minimum: -90, maximum: 90 } } },
    Feature: { type: 'object', required: ['type', 'id', 'geometry', 'properties'], properties: { type: { const: 'Feature' }, id: uuid, geometry: { type: 'object', required: ['type', 'coordinates'], properties: { type: { enum: ['Point', 'LineString', 'Polygon'] }, coordinates: {} } }, properties: { type: 'object', required: ['id', 'layer_id', 'kind', 'title'], properties: { id: uuid, layer_id: uuid, kind: { type: 'string' }, number: { type: 'integer' }, title: { type: 'string' } }, additionalProperties: true } } },
    ReportMetadata: { type: 'object', additionalProperties: false, required: ['external_report_id', 'ticket_id', 'completion_id', 'feature_id', 'technician', 'occurred_at'], properties: { external_report_id: uuid, ticket_id: { type: 'integer', minimum: 1 }, completion_id: uuid, feature_id: uuid, technician: { type: 'object', additionalProperties: false, required: ['id', 'name'], properties: { id: { type: 'string', minLength: 1, maxLength: 128 }, name: { type: 'string', minLength: 1, maxLength: 200 } } }, occurred_at: { type: 'string', format: 'date-time' }, text: { type: 'string', maxLength: 10000, default: '' } } },
    ReportReceipt: { type: 'object', required: ['id', 'external_report_id', 'repeated', 'retention_until'], properties: { id: uuid, external_report_id: uuid, repeated: { type: 'boolean' }, retention_until: { type: 'string', format: 'date-time', nullable: true } } },
  };
  const errors = { '401': response(schemas.Error, 'Недействительный токен'), '404': response(schemas.Error, 'Ресурс не найден'), '422': response(schemas.Error, 'Неподдерживаемый тип объекта или неверные данные') };
  return {
    openapi: '3.1.0',
    info: { title: 'Точка GIS Integration API', version: '1.0.0', description: `Серверный API для PWA. Bearer-токен не передаётся в браузер. Фото: до 5 файлов, JPEG/PNG/WebP, до 10 MiB каждый; отчёты разрешены только для ${config.reportGeometryTypes.join(', ')}. Файлы хранятся не менее ${config.photoRetentionDays} дней; дата минимального хранения возвращается в квитанции.` },
    servers: [{ url: '/' }], security: [{ bearerAuth: [] }],
    components: { securitySchemes: { bearerAuth: { type: 'http', scheme: 'bearer', bearerFormat: 'opaque token' } }, schemas },
    paths: {
      '/integration/v1/openapi.json': { get: { summary: 'Контракт API', responses: { '200': response({ type: 'object' }), ...errors } } },
      '/integration/v1/maps': { get: { summary: 'Опубликованные карты', responses: { '200': response({ type: 'object', required: ['rows'], properties: { rows: { type: 'array', items: { $ref: '#/components/schemas/Map' } } } }), ...errors } } },
      '/integration/v1/maps/{id}/layers': { get: { summary: 'Слои карты', parameters: [idParameter], responses: { '200': response({ type: 'object', required: ['rows'], properties: { rows: { type: 'array', items: { $ref: '#/components/schemas/Layer' } } } }), ...errors } } },
      '/integration/v1/maps/{id}/bounds': { get: { summary: 'Границы сети в WGS84', parameters: [idParameter], responses: { '200': response({ $ref: '#/components/schemas/Bounds' }), ...errors } } },
      '/integration/v1/maps/{id}/features': { get: { summary: 'GeoJSON объектов видимой области', parameters: [idParameter, { name: 'bbox', in: 'query', required: true, description: 'west,south,east,north в WGS84', schema: { type: 'string', pattern: '^-?\\d+(\\.\\d+)?,-?\\d+(\\.\\d+)?,-?\\d+(\\.\\d+)?,-?\\d+(\\.\\d+)?$' } }, { name: 'layers', in: 'query', description: 'До 32 UUID через запятую', schema: { type: 'string' } }], responses: { '200': response({ type: 'object', required: ['type', 'truncated', 'limit', 'features'], properties: { type: { const: 'FeatureCollection' }, truncated: { type: 'boolean' }, limit: { const: 40000 }, features: { type: 'array', maxItems: 40000, items: { $ref: '#/components/schemas/Feature' } } } }), ...errors } } },
      '/integration/v1/maps/{id}/search': { get: { summary: 'Поиск объектов', parameters: [idParameter, { name: 'q', in: 'query', required: true, schema: { type: 'string', minLength: 1, maxLength: 200 } }], responses: { '200': response({ type: 'object', required: ['rows'], properties: { rows: { type: 'array', maxItems: 100, items: { type: 'object' } } } }), ...errors } } },
      '/integration/v1/features/{id}': { get: { summary: 'Карточка объекта', parameters: [idParameter], responses: { '200': response({ type: 'object' }), ...errors } } },
      '/integration/v1/assets/{id}': { get: { summary: 'PNG-значок', parameters: [idParameter], responses: { '200': { description: 'PNG', content: { 'image/png': { schema: { type: 'string', format: 'binary' } } } }, ...errors } } },
      '/integration/v1/reports': { post: { summary: 'Сохранить идемпотентный фотоотчёт', description: 'Повтор с тем же external_report_id и тем же содержимым возвращает 200 и прежнюю квитанцию. Тот же ID с другими данными возвращает 409.', requestBody: { required: true, content: { 'multipart/form-data': { schema: { type: 'object', required: ['metadata'], properties: { metadata: { type: 'string', contentMediaType: 'application/json', contentSchema: { $ref: '#/components/schemas/ReportMetadata' } }, photos: { type: 'array', maxItems: 5, items: { type: 'string', format: 'binary' } } } } } } }, responses: { '201': response({ $ref: '#/components/schemas/ReportReceipt' }, 'Отчёт сохранён'), '200': response({ $ref: '#/components/schemas/ReportReceipt' }, 'Повтор предыдущего запроса'), '409': response(schemas.Error, 'Внешний ID использован с иным содержимым'), ...errors } } },
      '/integration/v1/reports/by-external-id/{id}': { get: { summary: 'Сверить квитанцию отчёта', parameters: [idParameter], responses: { '200': response({ $ref: '#/components/schemas/ReportReceipt' }), ...errors } } },
    },
  };
}
