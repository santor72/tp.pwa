import { createHash, timingSafeEqual } from 'node:crypto';
import { config as loadEnv } from 'dotenv';
import { fileURLToPath } from 'node:url';

// The integration module may be evaluated before the database module, which
// normally loads .env. Load the same private runtime file explicitly so that
// route installation is independent of ESM evaluation order.
loadEnv({ path: fileURLToPath(new URL('../.env', import.meta.url)), quiet: true });

export type IntegrationConfig = {
  clientId: string;
  tokenHash: Buffer;
  mapIds: string[] | null;
  reportGeometryTypes: string[];
  photoRetentionDays: number;
};

const clientId = /^[a-z][a-z0-9_-]{2,63}$/;
const uuid = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
const sha256 = /^[a-f0-9]{64}$/i;
const reportGeometryTypes = new Set(['Point', 'LineString', 'Polygon']);

export function integrationConfig(env: Record<string, string | undefined> = process.env): IntegrationConfig | null {
  const rawToken = env.GIS_INTEGRATION_TOKEN?.trim() ?? '';
  const configuredHash = env.GIS_INTEGRATION_TOKEN_SHA256?.trim() ?? '';
  if (!rawToken && !configuredHash) return null;
  if (rawToken && rawToken.length < 32) throw Error('GIS_INTEGRATION_TOKEN must contain at least 32 characters');
  if (configuredHash && !sha256.test(configuredHash)) throw Error('GIS_INTEGRATION_TOKEN_SHA256 must be a SHA-256 hex digest');
  if (env.NODE_ENV === 'production' && !configuredHash) throw Error('GIS_INTEGRATION_TOKEN_SHA256 is required in production');
  const id = env.GIS_INTEGRATION_CLIENT_ID?.trim() || 'tp-pwa';
  if (!clientId.test(id)) throw Error('Invalid GIS_INTEGRATION_CLIENT_ID');
  const values = (env.GIS_INTEGRATION_MAP_IDS ?? '').split(',').map(value => value.trim()).filter(Boolean);
  if (values.some(value => !uuid.test(value))) throw Error('GIS_INTEGRATION_MAP_IDS must contain UUID values');
  if (env.NODE_ENV === 'production' && !values.length) throw Error('GIS_INTEGRATION_MAP_IDS is required in production');
  const types = (env.GIS_INTEGRATION_REPORT_GEOMETRY_TYPES ?? 'Point,LineString').split(',').map(value => value.trim()).filter(Boolean);
  if (!types.length || types.some(value => !reportGeometryTypes.has(value))) throw Error('GIS_INTEGRATION_REPORT_GEOMETRY_TYPES must contain Point, LineString, or Polygon');
  const retention = Number(env.GIS_INTEGRATION_PHOTO_RETENTION_DAYS ?? 365);
  if (!Number.isInteger(retention) || retention < 30 || retention > 3650) throw Error('GIS_INTEGRATION_PHOTO_RETENTION_DAYS must be an integer between 30 and 3650');
  return { clientId: id, tokenHash: Buffer.from(configuredHash || createHash('sha256').update(rawToken).digest('hex'), 'hex'), mapIds: values.length ? [...new Set(values)] : null, reportGeometryTypes: [...new Set(types)], photoRetentionDays: retention };
}

export function integrationAuthorized(header: string | undefined, config: IntegrationConfig | null): boolean {
  if (!config || !header?.startsWith('Bearer ')) return false;
  const supplied = createHash('sha256').update(header.slice(7), 'utf8').digest();
  const expected = config.tokenHash;
  return supplied.length === expected.length && timingSafeEqual(supplied, expected);
}

export function integrationMapAllowed(mapId: string, config: IntegrationConfig): boolean {
  return config.mapIds === null || config.mapIds.includes(mapId);
}
