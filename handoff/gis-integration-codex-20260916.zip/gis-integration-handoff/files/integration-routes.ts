import type { Hono } from 'hono';
import { z } from 'zod';
import { createHash, randomUUID } from 'node:crypto';
import { mkdir, statfs, writeFile } from 'node:fs/promises';
import { pool, dataDir } from './lib/db';
import { PublicError } from './lib/public-error';
import { inspectPhoto } from './lib/photo-format';
import { integrationAuthorized, integrationConfig, integrationMapAllowed, type IntegrationConfig } from './lib/integration-config';
import { enqueueReport, type TelegramConfig } from './lib/telegram-reports';
import { integrationOpenApi } from './integration-openapi';

const id = z.string().uuid();
const bbox = z.array(z.number().finite()).length(4).refine(([west, south, east, north]) => west < east && south < north && west >= -180 && east <= 180 && south >= -90 && north <= 90);
const reportMeta = z.object({
  external_report_id: id,
  ticket_id: z.coerce.number().int().positive(),
  completion_id: id,
  feature_id: id,
  technician: z.object({ id: z.string().min(1).max(128), name: z.string().trim().min(1).max(200) }).strict(),
  occurred_at: z.string().datetime({ offset: true }),
  text: z.string().trim().max(10000).default(''),
}).strict();
const root = dataDir + 'photos/';
const hash = (bytes: Uint8Array) => createHash('sha256').update(bytes).digest('hex');

type Photo = { id: string; mime: string; extension: string; width: number; height: number; bytes: number; sha256: string };

function mapFilter(config: IntegrationConfig, offset = 1): { sql: string; values: unknown[] } {
  return config.mapIds === null ? { sql: 'TRUE', values: [] } : { sql: `i.id=ANY($${offset}::uuid[])`, values: [config.mapIds] };
}

async function form(c: any) {
  try { return await c.req.formData(); }
  catch { throw new PublicError('Не удалось прочитать форму отчёта'); }
}

export function installIntegration(app: Hono, telegram: TelegramConfig | null = null) {
  const config = integrationConfig();
  app.use('/integration/v1/*', async (c, next) => {
    if (!integrationAuthorized(c.req.header('authorization'), config)) return c.json({ code: 'INTEGRATION_UNAUTHORIZED', error: 'Недействительный токен интеграции' }, 401);
    await next();
  });
  if (!config) return;
  const allowed = (mapId: string) => integrationMapAllowed(mapId, config);

  app.get('/integration/v1/openapi.json', c => c.json(integrationOpenApi(config)));
  app.get('/integration/v1/maps', async c => {
    const filter = mapFilter(config);
    const rows = (await pool.query(`SELECT i.id,i.name,i.created_at,
      jsonb_build_object('total',count(f.id)) report
      FROM imports i LEFT JOIN layers l ON l.import_id=i.id AND NOT l.deleted
      LEFT JOIN features f ON f.layer_id=l.id AND NOT f.deleted
      WHERE ${filter.sql} GROUP BY i.id,i.name,i.created_at ORDER BY i.created_at DESC`, filter.values)).rows;
    return c.json({ rows });
  });
  app.get('/integration/v1/maps/:id/layers', async c => {
    const mapId = id.parse(c.req.param('id'));
    if (!allowed(mapId)) return c.json({ code: 'MAP_NOT_FOUND', error: 'Карта не найдена' }, 404);
    return c.json({ rows: (await pool.query('SELECT id,name,position,count,version FROM layers WHERE import_id=$1 AND NOT deleted ORDER BY position,id', [mapId])).rows });
  });
  app.get('/integration/v1/maps/:id/bounds', async c => {
    const mapId = id.parse(c.req.param('id'));
    if (!allowed(mapId)) return c.json({ code: 'MAP_NOT_FOUND', error: 'Карта не найдена' }, 404);
    const row = (await pool.query(`SELECT ST_XMin(extent) xmin,ST_YMin(extent) ymin,ST_XMax(extent) xmax,ST_YMax(extent) ymax
      FROM (SELECT ST_Extent(f.geom) extent FROM features f JOIN layers l ON l.id=f.layer_id
        WHERE l.import_id=$1 AND NOT l.deleted AND NOT f.deleted AND f.geom IS NOT NULL) bounds`, [mapId])).rows[0];
    if (Object.values(row ?? {}).some(value => value === null)) return c.json({ code: 'MAP_EMPTY', error: 'В карте нет объектов с корректными координатами' }, 404);
    return c.json(row);
  });
  app.get('/integration/v1/maps/:id/features', async c => {
    const mapId = id.parse(c.req.param('id'));
    if (!allowed(mapId)) return c.json({ code: 'MAP_NOT_FOUND', error: 'Карта не найдена' }, 404);
    const area = bbox.parse((c.req.query('bbox') ?? '').split(',').map(Number));
    const layerIds = (c.req.query('layers') ?? '').split(',').filter(Boolean).map(value => id.parse(value));
    if (layerIds.length > 32) throw new PublicError('Можно выбрать не более 32 слоёв');
    const rows = (await pool.query(`SELECT f.id,f.layer_id,f.kind,f.title,f.number,f.geometry,f.style
      FROM features f JOIN layers l ON l.id=f.layer_id
      WHERE l.import_id=$1 AND NOT l.deleted AND NOT f.deleted
      AND ($2::uuid[] IS NULL OR f.layer_id=ANY($2))
      AND f.geom && ST_MakeEnvelope($3,$4,$5,$6,4326)
      ORDER BY l.position,f.number,f.id LIMIT 40001`, [mapId, layerIds.length ? layerIds : null, ...area])).rows;
    return c.json({ type: 'FeatureCollection', truncated: rows.length > 40000, limit: 40000, features: rows.slice(0, 40000).map(row => ({ type: 'Feature', id: row.id, geometry: row.geometry, properties: { id: row.id, layer_id: row.layer_id, kind: row.kind, number: row.number, title: row.title, ...row.style } })) });
  });
  app.get('/integration/v1/maps/:id/search', async c => {
    const mapId = id.parse(c.req.param('id'));
    if (!allowed(mapId)) return c.json({ code: 'MAP_NOT_FOUND', error: 'Карта не найдена' }, 404);
    const query = (c.req.query('q') ?? '').trim();
    if (!query || query.length > 200) throw new PublicError('Укажите поисковый запрос длиной до 200 символов');
    const rows = (await pool.query(`SELECT f.id,f.layer_id,f.kind,f.number,f.title,l.name layer_name,l.id map_layer_id,f.style
      FROM features f JOIN layers l ON l.id=f.layer_id WHERE l.import_id=$1 AND NOT l.deleted AND NOT f.deleted
      AND (f.title ILIKE $2 OR f.source_name ILIKE $2 OR f.description ILIKE $2 OR f.number::text=$3)
      ORDER BY l.position,f.number,f.id LIMIT 100`, [mapId, '%' + query.replace(/[\\%_]/g, '\\$&') + '%', query])).rows;
    return c.json({ rows });
  });
  app.get('/integration/v1/features/:id', async c => {
    const featureId = id.parse(c.req.param('id'));
    const filter = mapFilter(config, 2);
    const row = (await pool.query(`SELECT f.id,f.layer_id,f.number,f.kind,f.title,f.description,f.geometry,f.style,f.version,l.name layer_name,l.import_id map_id
      FROM features f JOIN layers l ON l.id=f.layer_id JOIN imports i ON i.id=l.import_id
      WHERE f.id=$1 AND NOT f.deleted AND NOT l.deleted AND ${filter.sql}`, [featureId, ...filter.values])).rows[0];
    return row ? c.json(row) : c.json({ code: 'FEATURE_NOT_FOUND', error: 'Объект не найден' }, 404);
  });
  app.get('/integration/v1/assets/:id', async c => {
    const assetId = id.parse(c.req.param('id'));
    const filter = mapFilter(config, 2);
    const row = (await pool.query(`SELECT a.disk_name FROM assets a JOIN imports i ON i.id=a.import_id WHERE a.id=$1 AND ${filter.sql}`, [assetId, ...filter.values])).rows[0];
    if (!row) return c.json({ code: 'ASSET_NOT_FOUND', error: 'Значок не найден' }, 404);
    return new Response(Bun.file(dataDir + row.disk_name), { headers: { 'Content-Type': 'image/png', 'Cache-Control': 'private, max-age=3600' } });
  });
  app.post('/integration/v1/reports', async c => {
    const data = await form(c);
    const raw = data.get('metadata');
    let metadata: z.infer<typeof reportMeta>;
    try { metadata = reportMeta.parse(typeof raw === 'string' ? JSON.parse(raw) : raw); }
    catch { throw new PublicError('Некорректные метаданные отчёта'); }
    const files = data.getAll('photos');
    if (files.length > 5 || files.some((file: FormDataEntryValue) => !(file instanceof File))) throw new PublicError('В одном отчёте можно загрузить до 5 фотографий');
    if (!metadata.text && !files.length) throw new PublicError('Добавьте текст или фотографию');
    const images: { bytes: Uint8Array; info: ReturnType<typeof inspectPhoto>; sha256: string }[] = [];
    for (const file of files as File[]) {
      if (file.size > 10 * 1024 * 1024) throw new PublicError('Размер одной фотографии — не более 10 МБ');
      const bytes = new Uint8Array(await file.arrayBuffer());
      images.push({ bytes, info: inspectPhoto(bytes), sha256: hash(bytes) });
    }
    const fingerprint = hash(new TextEncoder().encode(JSON.stringify({ feature: metadata.feature_id, ticket: metadata.ticket_id, completion: metadata.completion_id, technician: metadata.technician, occurredAt: metadata.occurred_at, text: metadata.text, photos: images.map(image => image.sha256) })));
    const db = await pool.connect();
    try {
      await db.query('BEGIN');
      await db.query('SELECT pg_advisory_xact_lock(hashtextextended($1,0))', [`integration-report:${config.clientId}:${metadata.external_report_id}`]);
      const previous = (await db.query('SELECT r.feature_report_id,r.fingerprint,h.feature_id,h.attachments FROM integration_report_receipts r JOIN feature_history_entries h ON h.id=r.feature_report_id WHERE r.client_id=$1 AND r.external_report_id=$2', [config.clientId, metadata.external_report_id])).rows[0];
      if (previous) {
        if (previous.fingerprint !== fingerprint || previous.feature_id !== metadata.feature_id) throw new PublicError('Этот внешний ID уже использован с другим содержимым', 409);
        await db.query('COMMIT');
        return c.json({ id: previous.feature_report_id, external_report_id: metadata.external_report_id, repeated: true, retention_until: previous.attachments?.retention?.retainUntil ?? null }, 200);
      }
      const object = (await db.query(`SELECT f.id,f.geometry,f.title,l.name layer_name,l.import_id map_id FROM features f JOIN layers l ON l.id=f.layer_id
        WHERE f.id=$1 AND NOT f.deleted AND NOT l.deleted`, [metadata.feature_id])).rows[0];
      if (!object || !allowed(object.map_id)) throw new PublicError('Выбранный объект недоступен', 404);
      if (!config.reportGeometryTypes.includes(object.geometry?.type)) throw new PublicError('Для этого типа объекта отчёт подключения не поддерживается', 422);
      const total = images.reduce((value, image) => value + image.bytes.length, 0);
      const reportId = randomUUID();
      const photos: Photo[] = [];
      if (images.length) {
        if (process.env.NODE_ENV !== 'production') await mkdir(root, { recursive: true, mode: 0o700 });
        const disk = await statfs(root);
        if (disk.bavail * disk.bsize < total + 1024 * 1024 * 1024) throw new PublicError('В фотоархиве мало свободного места', 503);
        const directory = root + reportId;
        await mkdir(directory, { recursive: true, mode: 0o700 });
        for (const image of images) {
          const photo = { id: randomUUID(), ...image.info, bytes: image.bytes.length, sha256: image.sha256 };
          await writeFile(directory + '/' + photo.id + '.' + photo.extension, image.bytes, { flag: 'wx', mode: 0o600 });
          photos.push(photo);
        }
      }
      const retentionUntil = new Date(Date.now() + config.photoRetentionDays * 24 * 60 * 60 * 1000).toISOString();
      const attachments = { version: 1, source: 'integration', clientId: config.clientId, externalReportId: metadata.external_report_id, ticketId: metadata.ticket_id, completionId: metadata.completion_id, technicianId: metadata.technician.id, occurredAt: metadata.occurred_at, fingerprint, bytes: total, photos, retention: { minimumDays: config.photoRetentionDays, retainUntil: retentionUntil } };
      await db.query("INSERT INTO feature_history_entries(id,feature_id,type,author,text,attachments,occurred_at) VALUES($1,$2,'photo-report',$3,$4,$5,$6)", [reportId, metadata.feature_id, metadata.technician.name, metadata.text, attachments, metadata.occurred_at]);
      await db.query('INSERT INTO integration_report_receipts(client_id,external_report_id,feature_report_id,fingerprint) VALUES($1,$2,$3,$4)', [config.clientId, metadata.external_report_id, reportId, fingerprint]);
      if (telegram) await enqueueReport(db, telegram, object.geometry.type, { reportId, mapId: object.map_id, featureId: metadata.feature_id, author: metadata.technician.name, layer: object.layer_name, title: object.title, text: metadata.text, photos });
      await db.query('COMMIT');
      return c.json({ id: reportId, external_report_id: metadata.external_report_id, repeated: false, retention_until: retentionUntil }, 201);
    } catch (error) { await db.query('ROLLBACK'); throw error; }
    finally { db.release(); }
  });
  app.get('/integration/v1/reports/by-external-id/:id', async c => {
    const externalId = id.parse(c.req.param('id'));
    const row = (await pool.query('SELECT r.feature_report_id,h.attachments FROM integration_report_receipts r JOIN feature_history_entries h ON h.id=r.feature_report_id WHERE r.client_id=$1 AND r.external_report_id=$2', [config.clientId, externalId])).rows[0];
    return row ? c.json({ id: row.feature_report_id, external_report_id: externalId, retention_until: row.attachments?.retention?.retainUntil ?? null }) : c.json({ code: 'REPORT_NOT_FOUND', error: 'Отчёт не найден' }, 404);
  });
}
